﻿using System;
using System.Linq;
using System.Xml.Serialization;

namespace EezyTool.LocalHub.XML
{
    [Serializable()]
    [XmlType(AnonymousType = true)]
    [XmlRoot("EezyTool", IsNullable = false)]
    public class LocalHubContainer
    {
        public LocalHubContainer()
        {

        }

        XmlWorkspaces workspaces;
        [XmlIgnore]
        public XmlWorkspaces Workspaces
        {
            get
            {
                if (workspaces == null)
                    workspaces = new XmlWorkspaces();
                return workspaces;
            }
            set { workspaces = value; }
        }

        [XmlArrayAttribute("Workspaces")]
        public XmlWorkspace[] WorkspaceArray
        {
            get { return Workspaces.ToArray(); }
            set
            {
                foreach (XmlWorkspace item in value)
                {
                    Workspaces.Add(item);
                }
            }
        }

    }
}
