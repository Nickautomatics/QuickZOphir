﻿using EezyTool.Core.Models;
using System;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Xml.Serialization;

namespace EezyTool.LocalHub.XML
{
    [Serializable()]
    [DesignerCategory("code")]    
    public class XmlWorkspace : WorkspaceItem
    {
        public XmlWorkspace()
            : base()
        {
            
        }
        [XmlIgnore]
        public bool IsLastActiveWorkSpace
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }


    }
}
