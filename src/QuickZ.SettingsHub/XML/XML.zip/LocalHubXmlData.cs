﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DevExpress.Data.Filtering;
using DevExpress.Xpo;
using DevExpress.Xpo.DB;
using DevExpress.Xpo.Metadata;
using EezyTool.Core.Helpers;
using EezyTool.Core;
using DevExpress.ExpressApp;

namespace EezyTool.LocalHub.XML
{
    public class LocalHubXmlData
    {
        public LocalHubXmlData(LocalHubContainer container, string file)
        {
            FileName = file;
            Container = container;
        }

        string fileName;
        public string FileName
        {
            get { return fileName; }
            set
            {
                fileName = value;
            }
        }

        LocalHubContainer container;
        public LocalHubContainer Container
        {
            get { return container; }
            set
            {
                container = value;
            }
        }
        

        public LocalHubContainer Import()
        {
            // Read xml file
            try
            {                
                EezyTool.Core.Helpers.XmlHelper<LocalHubContainer>.Deserialize(fileName, ref container, "");
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to read file.", ex);
            }

            return container;
        }

        public void Export()
        {
            // Read xml file
            try
            {
                EezyTool.Core.Helpers.XmlHelper<LocalHubContainer>.Serialize(fileName, container);
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to write to file.", ex);
            }

        }
    }
}
